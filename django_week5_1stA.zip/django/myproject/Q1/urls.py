# In your Django project's urls.py
from django.urls import path
from Q1.views import student_form

urlpatterns = [
    path('student-form/', student_form, name='student_form'),
    # Add other URL patterns as needed
]

