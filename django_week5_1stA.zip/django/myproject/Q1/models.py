# In your Q1 app's forms.py
from django import forms

class StudentForm(forms.Form):
    name = forms.CharField(max_length=100)
    date_of_birth = forms.DateField()
    address = forms.CharField(max_length=255)
    contact_number = forms.CharField(max_length=15)
    email = forms.EmailField()
    english_marks = forms.IntegerField()
    physics_marks = forms.IntegerField()
    chemistry_marks = forms.IntegerField()

