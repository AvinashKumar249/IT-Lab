# In your Q1 app's views.py
from django.shortcuts import render, redirect
from .forms import StudentForm

def student_form(request):
    if request.method == 'POST':
        form = StudentForm(request.POST)
        if form.is_valid():
            # Process the form data here (since we're not saving to a database)
            # For demonstration, we'll just print the data
            cleaned_data = form.cleaned_data
            print(cleaned_data)
            return redirect('success_url')  # Redirect to a success page
    else:
        form = StudentForm()
    return render(request, 'Q1/student_form.html', {'form': form})

