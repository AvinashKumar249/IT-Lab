from django.shortcuts import render
from datetime import datetime, timedelta
from .forms import PromotionCheckForm

def promotion_check(request):
    is_eligible = None
    if request.method == 'POST':
        form = PromotionCheckForm(request.POST)
        if form.is_valid():
            date_of_joining = form.cleaned_data['date_of_joining']
            years_of_experience = (datetime.now().date() - date_of_joining).days // 365
            is_eligible = "YES" if years_of_experience >= 5 else "NO"
    else:
        form = PromotionCheckForm()
    return render(request, 'promotion_check.html', {'form': form, 'is_eligible': is_eligible})

