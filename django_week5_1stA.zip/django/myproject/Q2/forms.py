from django import forms

class PromotionCheckForm(forms.Form):
    employee_id = forms.ChoiceField(choices=[(1, 'Employee 1'), (2, 'Employee 2'), (3, 'Employee 3')])
    date_of_joining = forms.DateField(widget=forms.DateInput(attrs={'type': 'date'}))

