from django.apps import AppConfig


class Q2Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Q2'
