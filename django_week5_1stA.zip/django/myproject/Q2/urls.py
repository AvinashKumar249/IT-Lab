from django.urls import path
from .views import promotion_check

urlpatterns = [
    path('promotion-check/', promotion_check, name='promotion_check'),
]

