from django.apps import AppConfig


class MyformConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Myform'
